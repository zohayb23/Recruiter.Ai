import os
import re
from typing import BinaryIO, Optional, List
from ...models.resume import ParsedResume, Contact, Education, WorkExperience, Skill
from datetime import datetime
import uuid
from fastapi import UploadFile, HTTPException
import docx
import PyPDF2
import io
import spacy
from sentence_transformers import SentenceTransformer
from ..vector_store.milvus_service import milvus_service
import logging
import magic

logger = logging.getLogger(__name__)

class ResumeParserService:
    def __init__(self):
        self.supported_extensions = ['.pdf', '.docx', '.doc', '.txt', '.rtf']
        # Load spaCy model for NER
        try:
            self.nlp = spacy.load('en_core_web_sm')
        except:
            os.system('python -m spacy download en_core_web_sm')
            self.nlp = spacy.load('en_core_web_sm')
        # Load sentence transformer for embeddings
        self.model = SentenceTransformer('all-MiniLM-L6-v2')

    async def parse_resume(self, file: UploadFile) -> ParsedResume:
        """Parse a resume file and extract structured information"""
        try:
            # Read file content
            content = await file.read()
            
            # Extract text based on file type
            text = self._extract_text_from_file(content, file.filename)
            logger.info(f"Extracted text from {file.filename}: {text[:200]}...")  # Log first 200 chars
            
            if not text.strip():
                raise ValueError("No text could be extracted from the file")

            # Process with spaCy
            doc = self.nlp(text)

            # Extract information
            contact_info = self._extract_contact_info(doc, text)
            education = self._extract_education(doc, text)
            work_experience = self._extract_work_experience(doc, text)
            skills = self._extract_skills(doc, text)
            
            # Generate embedding
            embedding = self.model.encode(text).tolist()

            # Create unique filename and save file
            file_ext = os.path.splitext(file.filename)[1].lower()
            unique_filename = f"{str(uuid.uuid4())}{file_ext}"
            upload_dir = "uploads/resumes"
            os.makedirs(upload_dir, exist_ok=True)
            file_path = os.path.join(upload_dir, unique_filename)
            
            with open(file_path, "wb") as buffer:
                # Reset file pointer to start
                await file.seek(0)
                buffer.write(await file.read())

            # Create ParsedResume object
            parsed_resume = ParsedResume(
                resume_id=str(uuid.uuid4()),
                full_name=contact_info.get('name', ''),
                contact=Contact(
                    email=contact_info.get('email', ''),
                    phone=contact_info.get('phone', ''),
                    linkedin=contact_info.get('linkedin', ''),
                    github=contact_info.get('github', ''),
                    website=contact_info.get('website', '')
                ),
                education=education,
                work_experience=work_experience,
                skills=skills,
                file_path=file_path,
                created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )

            # Store in Milvus
            try:
                await self._store_in_milvus(parsed_resume, embedding)
                logger.info(f"Successfully stored resume in Milvus: {parsed_resume.full_name}")
            except Exception as e:
                logger.error(f"Error storing in Milvus: {e}")

            return parsed_resume

        except Exception as e:
            logger.error(f"Error parsing resume: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    def _extract_text_from_file(self, content: bytes, filename: str) -> str:
        """Extract text from different file formats with improved encoding handling"""
        try:
            # Detect file type
            file_type = magic.from_buffer(content, mime=True)
            
            if file_type == 'application/pdf' or filename.lower().endswith('.pdf'):
                # PDF extraction
                pdf_file = io.BytesIO(content)
                pdf_reader = PyPDF2.PdfReader(pdf_file)
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
                return text

            elif file_type in ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
                             'application/msword'] or filename.lower().endswith(('.docx', '.doc')):
                # DOCX extraction
                doc_file = io.BytesIO(content)
                doc = docx.Document(doc_file)
                text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
                return text

            else:
                # Try different encodings
                encodings = ['utf-8', 'latin-1', 'ascii', 'cp1252']
                for encoding in encodings:
                    try:
                        return content.decode(encoding)
                    except UnicodeDecodeError:
                        continue
                
                # Fallback: force decode with utf-8, ignoring errors
                return content.decode('utf-8', errors='ignore')

        except Exception as e:
            logger.error(f"Error extracting text from {filename}: {e}")
            return ""

    def _extract_contact_info(self, doc, text: str) -> dict:
        """Extract contact information using regex and spaCy"""
        contact_info = {
            'name': '',
            'email': '',
            'phone': '',
            'linkedin': '',
            'github': '',
            'website': ''
        }

        # Extract name from the first few lines
        lines = text.split('\n')
        for line in lines[:5]:
            line = line.strip()
            if line and len(line.split()) >= 2 and len(line) < 50:
                # Skip lines that look like headers or contact info
                if not any(x in line.lower() for x in ['resume', 'cv', 'email', 'phone', '@']):
                    contact_info['name'] = line
                    break

        # If no name found in first lines, try spaCy NER
        if not contact_info['name']:
            for ent in doc.ents:
                if ent.label_ == 'PERSON':
                    contact_info['name'] = ent.text
                    break

        # Extract email
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        if emails:
            contact_info['email'] = emails[0]

        # Extract phone with multiple formats
        phone_patterns = [
            r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        ]
        for pattern in phone_patterns:
            phones = re.findall(pattern, text)
            if phones:
                contact_info['phone'] = phones[0]
                break

        # Extract LinkedIn URL
        linkedin_pattern = r'(?:https?:)?\/\/(?:[\w]+\.)?linkedin\.com\/in\/[A-z0-9_-]+\/?'
        linkedin = re.findall(linkedin_pattern, text, re.IGNORECASE)
        if linkedin:
            contact_info['linkedin'] = linkedin[0]

        # Extract GitHub URL
        github_pattern = r'(?:https?:)?\/\/(?:[\w]+\.)?github\.com\/[A-z0-9_-]+\/?'
        github = re.findall(github_pattern, text, re.IGNORECASE)
        if github:
            contact_info['github'] = github[0]

        return contact_info

    def _extract_education(self, doc, text: str) -> List[Education]:
        """Extract education information"""
        education_list = []
        education_keywords = ['degree', 'university', 'college', 'bachelor', 'master', 'phd', 'bs', 'ba', 'msc']
        
        # Find education section
        lines = text.split('\n')
        in_education = False
        current_education = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            line_lower = line.lower()
            
            # Check if this is an education section header
            if any(keyword in line_lower for keyword in education_keywords):
                in_education = True
                
                # Look for degree and institution
                degree = None
                institution = None
                
                # Try to find degree
                degree_patterns = [
                    r'(Bachelor|Master|PhD|B\.S\.|M\.S\.|B\.A\.|M\.A\.|MBA)',
                    r'(B\.?S\.?|M\.?S\.?|Ph\.?D\.?|MBA|B\.?A\.?|M\.?A\.?)'
                ]
                
                for pattern in degree_patterns:
                    matches = re.findall(pattern, line)
                    if matches:
                        degree = matches[0]
                        break
                
                # Look for institution in spaCy entities
                doc_line = self.nlp(line)
                for ent in doc_line.ents:
                    if ent.label_ == 'ORG':
                        institution = ent.text
                        break
                
                if degree or institution:
                    education_list.append(Education(
                        degree=degree if degree else line,
                        institution=institution if institution else "",
                        start_date="",
                        end_date=""
                    ))
        
        # If no education found, try to extract from the whole text
        if not education_list:
            for ent in doc.ents:
                if ent.label_ == 'ORG':
                    text_around = text[max(0, ent.start_char-50):min(len(text), ent.end_char+50)]
                    if any(keyword in text_around.lower() for keyword in education_keywords):
                        education_list.append(Education(
                            degree="Degree from " + ent.text,
                            institution=ent.text,
                            start_date="",
                            end_date=""
                        ))
                        break
        
        return education_list

    def _extract_work_experience(self, doc, text: str) -> List[WorkExperience]:
        """Extract work experience information"""
        experiences = []
        experience_keywords = ['experience', 'employment', 'work history', 'career']
        
        # Split into lines and find experience section
        lines = text.split('\n')
        in_experience = False
        current_experience = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            line_lower = line.lower()
            
            # Check if this is the start of experience section
            if any(keyword in line_lower for keyword in experience_keywords):
                in_experience = True
                continue
            
            if in_experience:
                # Look for job title and company patterns
                if ' at ' in line or ' - ' in line or '|' in line:
                    # Save previous experience if exists
                    if current_experience:
                        experiences.append(current_experience)
                    
                    # Parse new experience
                    parts = re.split(r'\s+(?:at|-|\|)\s+', line, maxsplit=1)
                    title = parts[0].strip()
                    company = parts[1].strip() if len(parts) > 1 else ""
                    
                    current_experience = WorkExperience(
                        title=title,
                        company=company,
                        start_date="",
                        end_date="",
                        description=[],
                        technologies=[]
                    )
                
                # Look for bullet points or description
                elif line.startswith(('•', '-', '*', '›', '»')) and current_experience:
                    current_experience.description.append(line.lstrip('•-*›» '))
                
                # Look for dates
                date_pattern = r'(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[,\s]+\d{4}'
                dates = re.findall(date_pattern, line)
                if dates and current_experience:
                    if not current_experience.start_date:
                        current_experience.start_date = dates[0]
                    if len(dates) > 1:
                        current_experience.end_date = dates[-1]
                    elif 'present' in line_lower:
                        current_experience.end_date = 'Present'
        
        # Add the last experience
        if current_experience:
            experiences.append(current_experience)
        
        # Extract technologies from descriptions
        tech_pattern = r'\b(?:Python|Java|JavaScript|TypeScript|React|Angular|Vue|Node\.js|Express|Django|Flask|Spring|SQL|MongoDB|PostgreSQL|MySQL|AWS|Azure|GCP|Docker|Kubernetes)\b'
        for exp in experiences:
            tech_set = set()
            for desc in exp.description:
                techs = re.findall(tech_pattern, desc)
                tech_set.update(techs)
            exp.technologies = list(tech_set)
        
        return experiences

    def _extract_skills(self, doc, text: str) -> List[Skill]:
        """Extract skills with improved accuracy"""
        skills = []
        skill_patterns = {
            'Programming': [
                'Python', 'Java', 'JavaScript', 'TypeScript', 'C++', 'C#', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Go'
            ],
            'Web Development': [
                'HTML', 'CSS', 'React', 'Angular', 'Vue', 'Node.js', 'Express', 'Django', 'Flask', 'Bootstrap'
            ],
            'Database': [
                'SQL', 'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Oracle', 'DynamoDB', 'Elasticsearch'
            ],
            'Cloud & DevOps': [
                'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Jenkins', 'Git', 'CI/CD', 'Terraform'
            ],
            'Data Science': [
                'Machine Learning', 'Deep Learning', 'TensorFlow', 'PyTorch', 'Pandas', 'NumPy', 'scikit-learn'
            ]
        }
        
        # Find skills section
        lines = text.split('\n')
        in_skills = False
        skills_text = ""
        
        for line in lines:
            line_lower = line.lower()
            if 'skills' in line_lower or 'technologies' in line_lower:
                in_skills = True
                continue
            if in_skills:
                if any(header in line_lower for header in ['experience', 'education', 'projects']):
                    break
                skills_text += line + " "
        
        # If no skills section found, use entire text
        if not skills_text:
            skills_text = text
        
        # Extract skills by category
        found_skills = set()
        for category, pattern_list in skill_patterns.items():
            for skill in pattern_list:
                if re.search(r'\b' + re.escape(skill) + r'\b', skills_text, re.IGNORECASE):
                    if skill.lower() not in [s.lower() for s in found_skills]:
                        found_skills.add(skill)
                        skills.append(Skill(name=skill, category=category))
        
        # Extract additional skills from bullet points or comma-separated lists
        additional_skills = re.findall(r'[•\-\*]\s*([^•\-\*\n]+)', skills_text)
        for skill_text in additional_skills:
            for skill in skill_text.split(','):
                skill = skill.strip()
                if (len(skill) > 2 and len(skill) < 30 and 
                    skill.lower() not in [s.lower() for s in found_skills]):
                    skills.append(Skill(name=skill, category='Other'))
                    found_skills.add(skill)
        
        return skills

    async def _store_in_milvus(self, resume: ParsedResume, embedding: List[float]):
        """Store the parsed resume in Milvus"""
        try:
            # Prepare data for Milvus
            milvus_data = {
                "resume_id": resume.resume_id,
                "full_name": resume.full_name,
                "email": resume.contact.email,
                "phone": resume.contact.phone,
                "linkedin": resume.contact.linkedin,
                "github": resume.contact.github,
                "website": resume.contact.website,
                "file_path": resume.file_path,
                "skills": resume.skills,
                "education": resume.education,
                "work_experience": resume.work_experience,
                "created_at": resume.created_at,
                "embedding": embedding
            }
            
            # Store in Milvus
            milvus_service.insert_resume(milvus_data)
            logger.info(f"Successfully stored resume in Milvus: {resume.full_name}")
            
        except Exception as e:
            logger.error(f"Error storing resume in Milvus: {e}")
            raise HTTPException(status_code=500, detail=f"Error storing resume in Milvus: {str(e)}")

resume_parser_service = ResumeParserService()