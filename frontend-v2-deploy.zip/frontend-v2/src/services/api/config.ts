// API configuration
export const API_BASE_URL = process.env.NODE_ENV === 'production'
  ? process.env.VITE_API_URL || 'https://recruiter-ai-backend-xxxxx-uc.a.run.app'  // Will be replaced with actual Cloud Run URL
  : 'http://localhost:8804';

import axios from 'axios';

// Create axios instance with default config
export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('Response error:', error.response?.data || error);
    return Promise.reject(error);
  }
);