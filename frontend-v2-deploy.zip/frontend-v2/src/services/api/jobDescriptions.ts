import { api } from './config';

export interface Responsibility {
  description: string;
  is_required: boolean;
}

export interface Qualification {
  description: string;
  is_required: boolean;
}

export interface Benefit {
  title: string;
  description: string;
}

export interface JobDescription {
  title: string;
  company?: string;
  department?: string;
  experience_level?: string;
  overview?: string;
  responsibilities?: Responsibility[];
  qualifications?: Qualification[];
  required_skills?: string[];
  preferred_skills?: string[];
  benefits?: Benefit[];
  company_description?: string;
  culture_values?: string;
  diversity_statement?: string;
  status?: string;
}

export interface JobDescriptionResponse extends JobDescription {
  id: string;
  created_at: string;
  updated_at: string;
  status: string;
}

export interface JobDescriptionSuggestions {
  inclusive_language: string[];
  clarity_improvements: string[];
  attractiveness_suggestions: string[];
  technical_accuracy: string[];
  culture_fit: string[];
}

export interface MarketAnalysis {
  salary_range: {
    min: number;
    max: number;
    currency: string;
    notes?: string;
  };
  skills_alignment: {
    score: number;
    trending_skills: string[];
    missing_skills: string[];
    notes?: string;
  };
  experience_match: {
    score: number;
    market_average: string;
    notes?: string;
  };
  title_accuracy: {
    score: number;
    alternative_titles: string[];
    notes?: string;
  };
}

export interface GenerateJobDescriptionParams {
  title: string;
  company?: string;
  department?: string;
  experience_level?: string;
  required_skills?: string[];
  company_info?: {
    name: string;
    industry: string;
    size: string;
    description?: string;
  };
}

export const generateJobDescription = async (data: {
  title: string;
  company?: string;
  department?: string;
  experience_level?: string;
  required_skills?: string[];
}) => {
  const response = await api.post('/job-descriptions/generate', data);
  return response.data;
};

export const saveJobDescription = async (data: JobDescription): Promise<JobDescriptionResponse> => {
  const response = await api.post('/job-descriptions/save', data);
  return response.data;
};

export const getDraftJobDescriptions = async (): Promise<JobDescriptionResponse[]> => {
  const response = await api.get('/job-descriptions/drafts');
  return response.data;
};

export const getJobDescription = async (id: string): Promise<JobDescriptionResponse> => {
  const response = await api.get(`/job-descriptions/${id}`);
  return response.data;
};

export const listJobDescriptions = async () => {
  const response = await api.get<JobDescription[]>('/job-descriptions');
  return response.data;
};

export const createJobDescription = async (data: JobDescription) => {
  const response = await api.post<JobDescription>('/job-descriptions', data);
  return response.data;
};

export const updateJobDescription = async (id: string, data: Partial<JobDescription>) => {
  const response = await api.put<JobDescription>(`/job-descriptions/${id}`, data);
  return response.data;
};

export const deleteJobDescription = async (id: string) => {
  await api.delete(`/job-descriptions/${id}`);
};

export const publishJobDescription = async (id: string) => {
  const response = await api.post<JobDescription>(`/job-descriptions/${id}/publish`);
  return response.data;
};

export const archiveJobDescription = async (id: string) => {
  const response = await api.post<JobDescription>(`/job-descriptions/${id}/archive`);
  return response.data;
};

export const improveJobDescription = async (id: string) => {
  const response = await api.post<JobDescriptionSuggestions>(`/job-descriptions/${id}/improve`);
  return response.data;
};

export const analyzeMarketAlignment = async (id: string) => {
  const response = await api.post<MarketAnalysis>(`/job-descriptions/${id}/market-analysis`);
  return response.data;
}; 