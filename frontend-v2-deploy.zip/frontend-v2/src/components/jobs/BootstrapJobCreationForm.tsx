import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  generateJobDescription,
  saveJobDescription,
  type JobDescription,
  type Responsibility,
  type Qualification,
  type Benefit,
  type JobDescriptionSuggestions,
  type MarketAnalysis,
  improveJobDescription,
  analyzeMarketAlignment
} from '../../services/api/jobDescriptions';
import { toast } from 'react-toastify';

interface FormData extends JobDescription {
  title: string;
  company: string;
  department: string;
  experience_level: string;
  overview: string;
  responsibilities: Responsibility[];
  qualifications: Qualification[];
  required_skills: string[];
  preferred_skills: string[];
  benefits: Benefit[];
  company_description: string;
  culture_values: string;
  diversity_statement: string;
}

export const BootstrapJobCreationForm: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
  title: '',
  company: '',
  department: '',
    experience_level: '',
    overview: '',
    responsibilities: [],
    qualifications: [],
    required_skills: [],
    preferred_skills: [],
    benefits: [],
    company_description: '',
    culture_values: '',
    diversity_statement: ''
  });

  const [newSkill, setNewSkill] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<JobDescriptionSuggestions | null>(null);
  const [marketAnalysis, setMarketAnalysis] = useState<MarketAnalysis | null>(null);
  const [showGeneratedContent, setShowGeneratedContent] = useState(false);

  const handleGenerateJobDescription = async () => {
    try {
      setIsGenerating(true);
      setError(null);

      const response = await generateJobDescription({
        title: formData.title,
        company: formData.company || undefined,
        department: formData.department || undefined,
        experience_level: formData.experience_level || undefined,
        required_skills: formData.required_skills.length > 0 ? formData.required_skills : undefined
      });

      // Update form data with the response
      setFormData(prev => ({
        ...prev,
        overview: response.overview || '',
        responsibilities: (response.responsibilities || []).map((r: any) => 
          typeof r === 'string' ? { description: r, is_required: true } : r as Responsibility
        ),
        qualifications: (response.qualifications || []).map((q: any) => 
          typeof q === 'string' ? { description: q, is_required: true } : q as Qualification
        ),
        required_skills: response.required_skills || prev.required_skills,
        preferred_skills: response.preferred_skills || [],
        benefits: (response.benefits || []).map((b: any) => 
          typeof b === 'string' ? { title: b, description: '' } : b as Benefit
        ),
        company_description: response.company_description || '',
        culture_values: response.culture_values || '',
        diversity_statement: response.diversity_statement || ''
      }));

      // Show the generated content section
      setShowGeneratedContent(true);

      // Scroll to the generated content
      setTimeout(() => {
        const generatedContent = document.getElementById('generatedContent');
        if (generatedContent) {
          generatedContent.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);

    } catch (err: any) {
      console.error('Error generating job description:', err);
      setError(err.response?.data?.detail || err.message || 'Error generating job description');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleImproveJobDescription = async (jdId: string) => {
    try {
      setIsGenerating(true);
      setError(null);

      const suggestions = await improveJobDescription(jdId);
      setSuggestions(suggestions);

    } catch (err: any) {
      console.error('Error improving job description:', err);
      setError(err.response?.data?.message || 'Error improving job description');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAnalyzeMarketAlignment = async (jdId: string) => {
    try {
      setIsGenerating(true);
      setError(null);

      const analysis = await analyzeMarketAlignment(jdId);
      setMarketAnalysis(analysis);

    } catch (err: any) {
      console.error('Error analyzing market alignment:', err);
      setError(err.response?.data?.message || 'Error analyzing market alignment');
      } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveAsDraft = async () => {
    try {
      setIsSaving(true);
      setError(null);

      // Clean up the data before sending
      const cleanedData: JobDescription = {
        title: formData.title,
        company: formData.company || undefined,
        department: formData.department || undefined,
        experience_level: formData.experience_level || undefined,
        overview: formData.overview || undefined,
        responsibilities: formData.responsibilities.map(r => ({
          description: r.description,
          is_required: r.is_required
        })),
        qualifications: formData.qualifications.map(q => ({
          description: q.description,
          is_required: q.is_required
        })),
        required_skills: formData.required_skills.length > 0 ? formData.required_skills : undefined,
        preferred_skills: formData.preferred_skills.length > 0 ? formData.preferred_skills : undefined,
        benefits: formData.benefits.map(b => ({
          title: b.title,
          description: b.description || ''
        })),
        company_description: formData.company_description || undefined,
        culture_values: formData.culture_values || undefined,
        diversity_statement: formData.diversity_statement || undefined,
        status: 'draft'
      };

      await saveJobDescription(cleanedData);

      // Show success message
      toast.success('Job description saved as draft successfully!');

    } catch (err: any) {
      console.error('Error saving job description:', err);
      // Extract error message from various possible formats
      const errorMessage = err.response?.data?.detail 
        ? Array.isArray(err.response.data.detail)
          ? err.response.data.detail[0]?.msg || JSON.stringify(err.response.data.detail)
          : typeof err.response.data.detail === 'object'
            ? err.response.data.detail.msg || JSON.stringify(err.response.data.detail)
            : err.response.data.detail
        : err.message || 'Error saving job description';
      
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddSkill = () => {
    if (newSkill.trim()) {
      setFormData(prev => ({
        ...prev,
        required_skills: [...prev.required_skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  return (
    <div className="container-fluid">
      <div className="card shadow mb-4">
        <div className="card-header py-3 d-flex justify-content-between align-items-center">
          <h6 className="m-0 font-weight-bold text-primary">Create New Job Posting</h6>
          <div>
            <button
              className="btn btn-primary me-2"
              onClick={handleGenerateJobDescription}
              disabled={!formData.title || isGenerating}
            >
              {isGenerating ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Generating...
                </>
              ) : (
                <>
                  <i className="fas fa-magic me-2"></i>
                  Generate Job Description
                </>
              )}
            </button>
          <button 
              className="btn btn-secondary"
              onClick={handleSaveAsDraft}
              disabled={!formData.title || isSaving}
            >
              {isSaving ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Saving...
                </>
              ) : (
                <>
                  <i className="fas fa-save me-2"></i>
                  Save as Draft
                </>
              )}
          </button>
          </div>
        </div>
        <div className="card-body">
          {error && typeof error === 'string' && (
            <div className="alert alert-danger mb-4" role="alert">
              {error}
            </div>
          )}

          {suggestions && (
            <div className="alert alert-info mb-4">
              <h6 className="font-weight-bold">Improvement Suggestions</h6>
              <div className="mt-3">
                <h6 className="font-weight-bold">Inclusive Language</h6>
                <ul>
                  {suggestions.inclusive_language.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
                <h6 className="font-weight-bold">Clarity Improvements</h6>
                <ul>
                  {suggestions.clarity_improvements.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
                <h6 className="font-weight-bold">Attractiveness</h6>
                <ul>
                  {suggestions.attractiveness_suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
                <h6 className="font-weight-bold">Technical Accuracy</h6>
                <ul>
                  {suggestions.technical_accuracy.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
                <h6 className="font-weight-bold">Culture Fit</h6>
                <ul>
                  {suggestions.culture_fit.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {marketAnalysis && (
            <div className="alert alert-info mb-4">
              <h6 className="font-weight-bold">Market Analysis</h6>
              <div className="mt-3">
                <h6 className="font-weight-bold">Salary Range</h6>
                <p>
                  {marketAnalysis.salary_range.currency} {marketAnalysis.salary_range.min.toLocaleString()} - {marketAnalysis.salary_range.max.toLocaleString()}
                  {marketAnalysis.salary_range.notes && (
                    <small className="d-block text-muted">{marketAnalysis.salary_range.notes}</small>
                  )}
                </p>

                <h6 className="font-weight-bold">Skills Alignment</h6>
                <p>Score: {marketAnalysis.skills_alignment.score}/100</p>
                {marketAnalysis.skills_alignment.trending_skills.length > 0 && (
                  <>
                    <p className="mb-1">Trending Skills:</p>
                    <ul>
                      {marketAnalysis.skills_alignment.trending_skills.map((skill, index) => (
                        <li key={index}>{skill}</li>
                      ))}
                    </ul>
                  </>
                )}
                {marketAnalysis.skills_alignment.missing_skills.length > 0 && (
                  <>
                    <p className="mb-1">Missing Skills:</p>
                    <ul>
                      {marketAnalysis.skills_alignment.missing_skills.map((skill, index) => (
                        <li key={index}>{skill}</li>
                      ))}
                    </ul>
                  </>
                )}
                {marketAnalysis.skills_alignment.notes && (
                  <small className="d-block text-muted">{marketAnalysis.skills_alignment.notes}</small>
                )}

                <h6 className="font-weight-bold">Experience Match</h6>
                <p>Score: {marketAnalysis.experience_match.score}/100</p>
                <p>Market Average: {marketAnalysis.experience_match.market_average}</p>
                {marketAnalysis.experience_match.notes && (
                  <small className="d-block text-muted">{marketAnalysis.experience_match.notes}</small>
                )}

                <h6 className="font-weight-bold">Title Accuracy</h6>
                <p>Score: {marketAnalysis.title_accuracy.score}/100</p>
                {marketAnalysis.title_accuracy.alternative_titles.length > 0 && (
                  <>
                    <p className="mb-1">Alternative Titles:</p>
                    <ul>
                      {marketAnalysis.title_accuracy.alternative_titles.map((title, index) => (
                        <li key={index}>{title}</li>
                      ))}
                    </ul>
                  </>
                )}
                {marketAnalysis.title_accuracy.notes && (
                  <small className="d-block text-muted">{marketAnalysis.title_accuracy.notes}</small>
                )}
              </div>
            </div>
          )}

          <form>
            <div className="mb-4">
              <h5>Basic Information</h5>
            <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="jobTitle" className="form-label">Job Title *</label>
                  <input
                    type="text"
                    className="form-control"
                    id="jobTitle"
                    placeholder="e.g., Senior Software Engineer"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                  <small className="text-muted">This is the only required field. Our AI will help generate the rest!</small>
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="company" className="form-label">Company</label>
                  <input
                    type="text"
                    className="form-control"
                    id="company"
                    placeholder="Enter company name (optional)"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="department" className="form-label">Department</label>
                  <input
                    type="text"
                    className="form-control"
                    id="department"
                    placeholder="e.g., Engineering (optional)"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="experienceLevel" className="form-label">Experience Level</label>
                  <select
                    className="form-select"
                    id="experienceLevel"
                    value={formData.experience_level}
                    onChange={(e) => setFormData({ ...formData, experience_level: e.target.value })}
                  >
                    <option value="">Select experience level (optional)</option>
                    <option value="Entry">Entry Level</option>
                    <option value="Mid">Mid Level</option>
                    <option value="Senior">Senior Level</option>
                    <option value="Lead">Lead</option>
                    <option value="Executive">Executive</option>
                  </select>
                </div>
              </div>

              <div className="mb-3">
                <label htmlFor="skills" className="form-label">Key Skills</label>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    id="skills"
                    placeholder="Enter key skills (optional)"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                  />
                  <button
                    className="btn btn-outline-primary"
                    type="button"
                    onClick={handleAddSkill}
                  >
                    Add
                  </button>
                </div>
                <small className="text-muted">Add any key skills for the role (optional). Our AI will suggest additional relevant skills.</small>
              </div>

              <div className="skills-list mb-4">
                {formData.required_skills.map((skill, index) => (
                  <div key={index} className="alert alert-info d-flex justify-content-between align-items-center">
                    <span>{skill}</span>
                    <button
                      type="button"
                      className="btn-close"
                      onClick={() => {
                        const newSkills = [...formData.required_skills];
                        newSkills.splice(index, 1);
                        setFormData({ ...formData, required_skills: newSkills });
                      }}
                    ></button>
                  </div>
                ))}
              </div>
            </div>

            {/* Generated Content */}
            {showGeneratedContent && (
              <div id="generatedContent" className="mb-4">
                <h5>Generated Job Description</h5>
                <div className="alert alert-success">
                  <i className="fas fa-check-circle me-2"></i>
                  Job description generated successfully! Review and edit the content below.
                </div>

                {/* Overview */}
                <div className="mb-4">
                  <label htmlFor="overview" className="form-label">Overview</label>
                  <textarea
                    className="form-control"
                    id="overview"
                    rows={5}
                    value={formData.overview}
                    onChange={(e) => setFormData({ ...formData, overview: e.target.value })}
                    placeholder="A compelling introduction about the role"
                  ></textarea>
                </div>

                {/* Responsibilities */}
                <div className="mb-4">
                  <h5>Responsibilities</h5>
                  <div className="mb-3">
                    {formData.responsibilities.map((resp, index) => (
                      <div key={index} className="mb-3">
                        <div className="input-group">
                          <input
                            type="text"
                            className="form-control"
                            value={resp.description}
                            onChange={(e) => {
                              const newResponsibilities = [...formData.responsibilities];
                              newResponsibilities[index].description = e.target.value;
                              setFormData({ ...formData, responsibilities: newResponsibilities });
                            }}
                            placeholder="Enter responsibility"
                          />
                          <div className="input-group-text">
                            <input
                              type="checkbox"
                              className="form-check-input mt-0"
                              checked={resp.is_required}
                              onChange={(e) => {
                                const newResponsibilities = [...formData.responsibilities];
                                newResponsibilities[index].is_required = e.target.checked;
                                setFormData({ ...formData, responsibilities: newResponsibilities });
                              }}
                            />
                            <span className="ms-2">Required</span>
                          </div>
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => {
                              const newResponsibilities = [...formData.responsibilities];
                              newResponsibilities.splice(index, 1);
                              setFormData({ ...formData, responsibilities: newResponsibilities });
                            }}
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary"
                      onClick={() => {
                        setFormData({
                          ...formData,
                          responsibilities: [
                            ...formData.responsibilities,
                            { description: '', is_required: true }
                          ]
                        });
                      }}
                    >
                      <i className="fas fa-plus me-2"></i>
                      Add Responsibility
                    </button>
                  </div>
                </div>

                {/* Qualifications */}
                <div className="mb-4">
                  <h5>Qualifications</h5>
                  <div className="mb-3">
                    {formData.qualifications.map((qual, index) => (
                      <div key={index} className="mb-3">
                        <div className="input-group">
                          <input
                            type="text"
                            className="form-control"
                            value={qual.description}
                            onChange={(e) => {
                              const newQualifications = [...formData.qualifications];
                              newQualifications[index].description = e.target.value;
                              setFormData({ ...formData, qualifications: newQualifications });
                            }}
                            placeholder="Enter qualification"
                          />
                          <div className="input-group-text">
                            <input
                              type="checkbox"
                              className="form-check-input mt-0"
                              checked={qual.is_required}
                              onChange={(e) => {
                                const newQualifications = [...formData.qualifications];
                                newQualifications[index].is_required = e.target.checked;
                                setFormData({ ...formData, qualifications: newQualifications });
                              }}
                            />
                            <span className="ms-2">Required</span>
                          </div>
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => {
                              const newQualifications = [...formData.qualifications];
                              newQualifications.splice(index, 1);
                              setFormData({ ...formData, qualifications: newQualifications });
                            }}
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary"
                      onClick={() => {
                        setFormData({
                          ...formData,
                          qualifications: [
                            ...formData.qualifications,
                            { description: '', is_required: true }
                          ]
                        });
                      }}
                    >
                      <i className="fas fa-plus me-2"></i>
                      Add Qualification
                    </button>
                  </div>
                </div>

                {/* Required Skills */}
                <div className="mb-4">
                  <h5>Required Skills</h5>
                  <div className="mb-3">
                    {formData.required_skills.map((skill, index) => (
                      <div key={index} className="alert alert-info d-flex justify-content-between align-items-center">
                        <span>{skill}</span>
                        <button
                          type="button"
                          className="btn-close"
                          onClick={() => {
                            const newSkills = [...formData.required_skills];
                            newSkills.splice(index, 1);
                            setFormData({ ...formData, required_skills: newSkills });
                          }}
                        ></button>
                      </div>
                    ))}
                    <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                        placeholder="Enter required skill"
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                      />
                      <button
                        className="btn btn-outline-primary"
                        type="button"
                        onClick={handleAddSkill}
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>

                {/* Preferred Skills */}
                <div className="mb-4">
                  <h5>Preferred Skills</h5>
                  <div className="mb-3">
                    {formData.preferred_skills.map((skill, index) => (
                      <div key={index} className="alert alert-secondary d-flex justify-content-between align-items-center">
                        <span>{skill}</span>
                        <button
                          type="button"
                          className="btn-close"
                          onClick={() => {
                            const newSkills = [...formData.preferred_skills];
                            newSkills.splice(index, 1);
                            setFormData({ ...formData, preferred_skills: newSkills });
                          }}
                        ></button>
                      </div>
                    ))}
                </div>
              </div>

                {/* Benefits */}
                <div className="mb-4">
                  <h5>Benefits</h5>
                  <div className="mb-3">
                    {formData.benefits.map((benefit, index) => (
                      <div key={index} className="mb-3">
                        <div className="input-group">
                  <input
                    type="text"
                            className="form-control"
                            value={benefit.title}
                            onChange={(e) => {
                              const newBenefits = [...formData.benefits];
                              newBenefits[index].title = e.target.value;
                              setFormData({ ...formData, benefits: newBenefits });
                            }}
                            placeholder="Benefit Title"
                          />
                  <input
                    type="text"
                            className="form-control"
                            value={benefit.description}
                            onChange={(e) => {
                              const newBenefits = [...formData.benefits];
                              newBenefits[index].description = e.target.value;
                              setFormData({ ...formData, benefits: newBenefits });
                            }}
                            placeholder="Benefit Description"
                          />
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => {
                              const newBenefits = [...formData.benefits];
                              newBenefits.splice(index, 1);
                              setFormData({ ...formData, benefits: newBenefits });
                            }}
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                </div>
              </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary"
                      onClick={() => {
                        setFormData({
                          ...formData,
                          benefits: [
                            ...formData.benefits,
                            { title: '', description: '' }
                          ]
                        });
                      }}
                    >
                      <i className="fas fa-plus me-2"></i>
                      Add Benefit
                    </button>
                </div>
              </div>

                {/* Company Information */}
                <div className="mb-4">
                  <h5>Company Information</h5>
                  <div className="mb-3">
                    <label htmlFor="companyDescription" className="form-label">Company Description</label>
                    <textarea
                      className="form-control"
                      id="companyDescription"
                      rows={3}
                      value={formData.company_description}
                      onChange={(e) => setFormData({ ...formData, company_description: e.target.value })}
                      placeholder="Enter company description"
                    ></textarea>
              </div>

                  <div className="mb-3">
                    <label htmlFor="cultureValues" className="form-label">Culture and Values</label>
                    <textarea
                    className="form-control"
                      id="cultureValues"
                      rows={3}
                      value={formData.culture_values}
                      onChange={(e) => setFormData({ ...formData, culture_values: e.target.value })}
                      placeholder="Enter company culture and values"
                    ></textarea>
              </div>

                  <div className="mb-3">
                    <label htmlFor="diversityStatement" className="form-label">Diversity Statement</label>
                    <textarea
                      className="form-control"
                      id="diversityStatement"
                      rows={3}
                      value={formData.diversity_statement}
                      onChange={(e) => setFormData({ ...formData, diversity_statement: e.target.value })}
                      placeholder="Enter diversity and inclusion statement"
                    ></textarea>
                  </div>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default BootstrapJobCreationForm; 