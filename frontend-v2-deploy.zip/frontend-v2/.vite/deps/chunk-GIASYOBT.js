import {
  createSvgIcon
} from "./chunk-IMAT3QDG.js";
import {
  require_jsx_runtime
} from "./chunk-FT54CQ4H.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/@mui/icons-material/esm/Business.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var Business_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M12 7V3H2v18h20V7zM6 19H4v-2h2zm0-4H4v-2h2zm0-4H4V9h2zm0-4H4V5h2zm4 12H8v-2h2zm0-4H8v-2h2zm0-4H8V9h2zm0-4H8V5h2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8zm-2-8h-2v2h2zm0 4h-2v2h2z"
}), "Business");

export {
  Business_default
};
//# sourceMappingURL=chunk-GIASYOBT.js.map
